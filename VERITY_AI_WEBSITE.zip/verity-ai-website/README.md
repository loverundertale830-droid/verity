# VERITY AI Website

A black-and-red AI chat website with:
- OpenAI-powered chat through a server-side Node.js backend
- Browser microphone input (when supported and permitted)
- Spoken replies using the browser's built-in speech synthesis
- Verity's witty, sarcastic personality
- No Python required

## Important security notes

- **Never put your OpenAI API key in `public/index.html`, client-side JavaScript, screenshots, or a public GitHub repository.**
- For online hosting, add the key as the `OPENAI_API_KEY` environment variable in the hosting dashboard.
- API use can cost money and is separate from a ChatGPT subscription. Check your API account's usage and billing before using it.
- This starter project has basic input limits and a small in-memory per-IP request throttle, but no user accounts, database, or durable abuse protection. The throttle resets when the service restarts and is not a complete defense. Before sharing widely, add stronger rate limiting, usage caps, and monitoring.
- Do not enter passwords, personal secrets, or sensitive information into the chat.

## Deploy online with Render (no Python)

You need a GitHub account and a Render account. Render's free web services can sleep after inactivity, so the first request after a quiet period may be slow.

1. Extract `VERITY_AI_WEBSITE.zip`.
2. Sign in to GitHub and create a **new private repository** named `verity-ai-website`.
3. Upload the project files and folders to that repository. Keep `public/index.html` inside the `public` folder. Do not upload a real API key or a `.env` file.
4. Open https://dashboard.render.com/ and create **New → Web Service**.
5. Connect your GitHub account and choose the `verity-ai-website` repository.
6. Set:
   - **Runtime / Language:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance type:** Free, if offered and suitable
7. Before or after deploying, open the service's **Environment** settings and add:
   - Key: `OPENAI_API_KEY`
   - Value: your OpenAI API key (paste it directly into Render's private environment field; never send it to me or commit it to GitHub)
   - Optional key: `OPENAI_MODEL`
   - Optional value: `gpt-4o-mini`
8. Save and deploy/redeploy. Wait for the deployment to finish.
9. Open the `onrender.com` URL Render gives you. Test a text message first, then allow microphone access to test voice input.

Render docs:
- Node/Express deployment: https://render.com/docs/deploy-node-express-app
- Environment variables and secrets: https://render.com/docs/configure-environment-variables

## API key setup

Create/manage API keys in the OpenAI Platform: https://platform.openai.com/api-keys

The OpenAI API may require its own billing setup; a ChatGPT subscription does not automatically include API usage.

## Run locally without Python (optional)

This app requires Node.js to run on your own computer. Since you asked not to install extra software, you can skip local running and deploy it online through Render instead. If you do want to run locally later, install Node.js, open a terminal in the project folder, then run:

```sh
npm install
npm start
```

Visit http://localhost:3000.

## Voice support

- Spoken replies use the browser's speech synthesis and the available system voices.
- Microphone input uses the Web Speech API when supported by the browser. Current Chrome/Edge usually support it; support and behavior vary.
- The browser may ask for microphone permission. Voice input generally requires HTTPS or localhost, so use the secure hosted URL.
- The voice is browser-selected and may differ between devices. It is not a cloned or custom Verity voice.

## Troubleshooting

- **AI KEY NOT SET:** Add `OPENAI_API_KEY` in Render → your service → Environment, save, and redeploy.
- **API key rejected:** Confirm the key is active and belongs to the OpenAI Platform API account.
- **Quota / rate limit:** Check API usage, billing, and limits in the OpenAI Platform.
- **Voice input does nothing:** Use a supported browser, allow microphone access, and reload the page.
- **App does not deploy:** Check the Render deploy logs. Confirm `package.json`, `server.js`, and `public/index.html` are in the repository root in the expected structure.
