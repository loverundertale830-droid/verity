const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";

app.disable("x-powered-by");
app.use(express.json({ limit: "30kb" }));

// Small in-memory per-IP throttle to reduce accidental API abuse.
// For a widely shared production site, use a durable rate limiter / edge protection too.
const requestCounts = new Map();
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 12;
app.use("/api/chat", (req, res, next) => {
  const now = Date.now();
  const ip = (req.headers["x-forwarded-for"] || req.socket.remoteAddress || "unknown")
    .toString().split(",")[0].trim();
  let entry = requestCounts.get(ip);
  if (!entry || now - entry.start >= WINDOW_MS) {
    entry = { start: now, count: 0 };
  }
  entry.count += 1;
  requestCounts.set(ip, entry);
  if (entry.count > MAX_REQUESTS_PER_WINDOW) {
    return res.status(429).json({ error: "Easy there. Verity needs a short breather — try again in a minute." });
  }
  // Keep the map from growing forever on small deployments.
  if (requestCounts.size > 2000) {
    for (const [key, value] of requestCounts) {
      if (now - value.start >= WINDOW_MS) requestCounts.delete(key);
    }
  }
  next();
});
app.use(express.static(path.join(__dirname, "public"), {
  extensions: ["html"],
  maxAge: process.env.NODE_ENV === "production" ? "1h" : 0
}));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({
      error: "Verity's AI brain isn't connected yet. The site owner needs to add OPENAI_API_KEY in the hosting dashboard."
    });
  }

  const messages = req.body && req.body.messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
    return res.status(400).json({ error: "Send between 1 and 20 recent messages." });
  }

  const allowed = [];
  for (const item of messages) {
    if (!item || !["user", "assistant"].includes(item.role) || typeof item.content !== "string") continue;
    const content = item.content.trim().slice(0, 4000);
    if (content) allowed.push({ role: item.role, content });
  }

  if (!allowed.length || allowed[allowed.length - 1].role !== "user") {
    return res.status(400).json({ error: "Your latest message must be a user message." });
  }

  try {
    const client = new OpenAI({ apiKey, timeout: 45000, maxRetries: 1 });
    const response = await client.chat.completions.create({
      model: MODEL,
      messages: [
        {
          role: "system",
          content: [
            "You are VERITY, a clever, confident AI assistant with a dark, theatrical, red-alert personality.",
            "Your tone is witty, sarcastic, and a little cheeky, but never cruel. Be genuinely useful when the user needs help.",
            "Keep most replies conversational and reasonably concise. Use clear steps for technical help.",
            "Do not claim to control devices, accounts, or systems you cannot access. Be honest about uncertainty.",
            "Never reveal secret keys or claim that user messages are private beyond what the website actually guarantees."
          ].join(" ")
        },
        ...allowed
      ],
      temperature: 0.8,
      max_tokens: 700
    });

    const answer = response.choices?.[0]?.message?.content?.trim();
    if (!answer) return res.status(502).json({ error: "Verity returned an empty reply. Try again." });
    res.json({ reply: answer });
  } catch (err) {
    console.error("OpenAI request failed:", err?.status || "", err?.message || "unknown error");
    if (err?.status === 401) {
      return res.status(502).json({ error: "The server rejected the API key. Check OPENAI_API_KEY in your hosting settings." });
    }
    if (err?.status === 429) {
      return res.status(429).json({ error: "The AI API is rate-limited or out of available quota. Check your API usage and billing settings." });
    }
    res.status(502).json({ error: "Verity couldn't reach the AI service. Check the server logs and try again." });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Verity AI listening on port ${PORT}`);
});
